'use client'

import React, { useState, useRef, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Textarea } from "@/components/ui/textarea"

export default function DockerLearningApp() {
  const [dockerfile, setDockerfile] = useState('')
  const [command, setCommand] = useState('')
  const [output, setOutput] = useState('')
  const [commandHistory, setCommandHistory] = useState([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [analysis, setAnalysis] = useState('')
  const outputRef = useRef(null)

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [output])

  const handleFileChange = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => setDockerfile(e.target.result)
      reader.readAsText(file)
    }
  }

  const handleUrlLoad = async () => {
    const url = prompt("Enter Dockerfile URL:")
    if (url) {
      try {
        const response = await fetch(url)
        const text = await response.text()
        setDockerfile(text)
      } catch (error) {
        console.error("Error loading Dockerfile:", error)
      }
    }
  }

  const simulateDockerCommand = async (cmd) => {
    try {
      const response = await fetch('/api/docker-simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, dockerfile: dockerfile })
      })
      const data = await response.json()
      return data.output
    } catch (error) {
      console.error("Error simulating Docker command:", error)
      return "Error: Unable to process command"
    }
  }

  const handleRunCommand = async () => {
    if (command.trim()) {
      const result = await simulateDockerCommand(command)
      setOutput(prev => `${prev}\n> ${command}\n${result}`)
      setCommandHistory(prev => [...prev, command])
      setHistoryIndex(-1)
      setCommand('')
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHistoryIndex(prev => {
        const newIndex = Math.min(prev + 1, commandHistory.length - 1)
        setCommand(commandHistory[commandHistory.length - 1 - newIndex] || '')
        return newIndex
      })
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHistoryIndex(prev => {
        const newIndex = Math.max(prev - 1, -1)
        setCommand(commandHistory[commandHistory.length - 1 - newIndex] || '')
        return newIndex
      })
    }
  }

  const handleAnalyzeOutput = async () => {
    try {
      const response = await fetch('/api/analyze-output', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ output: output })
      })
      const data = await response.json()
      setAnalysis(data.analysis)
    } catch (error) {
      console.error("Error analyzing output:", error)
      setAnalysis("Error: Unable to analyze output")
    }
  }

  return (
    <div className="flex flex-col h-screen">
      <div className="flex flex-1">
        <div className="w-1/3 p-4 bg-gray-100">
          <h2 className="text-xl font-bold mb-2">Dockerfile</h2>
          <div className="mb-2">
            <Input type="file" onChange={handleFileChange} accept=".dockerfile,.txt" />
            <Button onClick={handleUrlLoad} className="mt-2">Load from URL</Button>
          </div>
          <ScrollArea className="h-full">
            <Textarea
              value={dockerfile}
              onChange={(e) => setDockerfile(e.target.value)}
              className="w-full h-full"
              placeholder="Enter or load your Dockerfile here..."
            />
          </ScrollArea>
        </div>
        <div className="w-2/3 flex flex-col">
          <ScrollArea className="flex-grow p-4 bg-black text-green-400 font-mono" ref={outputRef}>
            <pre>{output}</pre>
          </ScrollArea>
          <div className="p-4 bg-gray-800 flex">
            <Input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyDown={handleKeyDown}
              onKeyPress={(e) => e.key === 'Enter' && handleRunCommand()}
              placeholder="Enter Docker command..."
              className="flex-grow mr-2 bg-gray-700 text-white"
            />
            <Button onClick={handleRunCommand}>Run</Button>
          </div>
        </div>
      </div>
      <div className="p-4 bg-gray-200">
        <Button onClick={handleAnalyzeOutput}>Analyze Output</Button>
        <ScrollArea className="h-40 mt-2 p-2 bg-white rounded">
          <pre>{analysis}</pre>
        </ScrollArea>
      </div>
    </div>
  )
}